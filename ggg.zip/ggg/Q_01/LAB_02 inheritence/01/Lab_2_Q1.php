<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php
	class Animal{
		public $family;
		public $food;
		function set_family($family){
			$this -> Family=$family;

}
	function get_family(){
		return $this -> family;
}
}
?>
</body>
</html>