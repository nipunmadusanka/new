<!DOCTYPE html>
<html>
<?php
class Animal
{
	public $family;
	public $food;
	function set_family($family)
	{
		$this-> family = $family;
}
	function get_family()
	{
		return $this-> family;
	}

}
?>
</html>